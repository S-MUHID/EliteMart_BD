// Per-page JS extracted from index.html

// Access restriction check (original inline script)
try {
    const isLoggedIn = sessionStorage.getItem('customerLoggedIn') === 'true';
    const restrictedPages = ['products', 'cart', 'order', 'orders', 'invoice'];
    const currentPageName = location.pathname.split('/').pop().split('.')[0] || 'index';
    if (!isLoggedIn && restrictedPages.includes(currentPageName)) {
        window.location.href = 'customer-login.html?next=' + encodeURIComponent(location.pathname + location.search);
    }
} catch (e) {
    console.warn('Index access check failed', e);
}

// Show customer name or Login link in header (extracted from bottom inline script)
(function(){
    const area = document.getElementById('customerArea');
    if(!area) return;
    const logged = sessionStorage.getItem('customerLoggedIn');
    const name = sessionStorage.getItem('customerName');
    if(logged === 'true'){
        area.innerHTML = `<a class="badge" href="orders.html" title="My orders">👤 ${name||'Account'}</a><a class="badge" href="#" id="custLogout">🚪 Logout</a>`;
        const lo = document.getElementById('custLogout');
        lo && lo.addEventListener('click',(e)=>{ e.preventDefault(); sessionStorage.removeItem('customerLoggedIn'); sessionStorage.removeItem('customerEmail'); sessionStorage.removeItem('customerName'); location.reload(); });
    } else {
        area.innerHTML = `<a class="badge" href="customer-login.html?next=index.html">🔐 Login</a>`;
    }
})();

// Additional page-specific JS can be added here
